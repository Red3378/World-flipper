# /latest/api/index.php/reproduce/post
                       
## Request
### Headers
```
Host: na.wdfp.kakaogames.com
Accept-Encoding: deflate, gzip
Accept: text/xml, application/xml, application/xhtml+xml, text/html;q=0.9, text/plain;q=0.8, text/css, image/png, image/jpeg, image/gif;q=0.8, application/x-shockwave-flash, video/mp4;q=0.9, flv-application/octet-stream;q=0.8, video/x-flv;q=0.7, audio/mp4, application/futuresplash, */*;q=0.5
User-Agent: Mozilla/5.0 (Android; U; en-US) AppleWebKit/533.19.4 (KHTML, like Gecko) AdobeAIR/51.0
x-flash-version: 51,0,1,1
Connection: Keep-Alive
Referer: app:/worldflipper_android_release.swf
Content-Type: application/x-www-form-urlencoded
PARAM: eed6e6607ed23644ab68667e24e6c9c214a012e1
GAME-APP-ID: 297417490
COUNTRY_CODE: us
APP_ID: 561429
KAKAO_PID: 984521158255
DEVICE_LANG: en
DEVICE_NAME: SM-S916U 14
APP_VER: 0.0.81
DEVICE: 2
Content-Length: 1664
```

### Body
```
{
  "os_name": "14",
  "device_log_sequence_number": 67,
  "device_id": 4122805419139.0,
  "info": "{\"error\":\"\\\"\u6b63\u5e38\u7cfb\u81ea\u52d5\u9001\u4fe1\\\"\",\"deviceId\":4122805419139,\"viewerId\":297417490,\"resourceVersion\":\"2.1.122\",\"date\":\"2024/06/22_16:45:29.821\",\"osName\":\"14\",\"logId\":\"0_4122805419139_67_latest\",\"client_version\":1461176325329,\"deviceName\":\"SM-S916U\",\"devConfigClass\":\"\u23af.\uff70.\u2011.\u2011.\u2011.\u2012.\u2212.\u23af.\uff70.\u23af.\u2212.\u2013.\u2012.\u2014.\u3192.int\",\"log_type\":8,\"stackTrace\":\"\",\"unixtime\":1719092729821,\"code\":\"M8\",\"capabilities\":\"A=t&SA=t&SV=t&EV=t&MP3=t&AE=t&VE=t&ACC=f&PR=f&SP=f&SB=f&DEB=f&V=AND%2051%2C0%2C1%2C1&M=Android%20Linux&R=1080x2340&COL=color&AR=1.0&OS=Linux%205.15.123-android13-8-28577312-abS916USQS3CXE3-SM-S916U&ARCH=ARM64&L=en&IME=true&PR32=true&PR64=true&CAS=64&PT=Desktop&AVD=f&LFD=f&WD=t&TLS=t&ML=5.1&DP=420\",\"screenWidth\":1080,\"timezone\":-6,\"prevUnixtime\":\"1719092711514\",\"buildTime\":\"2024/05/21_09:58:09\",\"appVersion\":\"0.0.81\",\"device\":\"2\",\"build_uuid\":\"356D02BA-772F-4F71-8B9F-664BF1A4CBF2FCAA\",\"screenHeight\":2340,\"buildVersionNumber\":\"0.0.81\",\"recentNote\":\"\",\"buildVersionPath\":\"\",\"startDate\":\"2024/06/22_16:40:48.541\",\"environment\":\"production---latest\",\"logSequenceNumber\":67,\"gitHash\":null}",
  "create_time": "2024/06/22_16:45:29.821",
  "device_name": "SM-S916U",
  "viewer_id": "297417490"
}
```

## Response
### Headers
```
Date: Sat, 22 Jun 2024 21:45:31 GMT
Content-Type: application/x-msgpack
Transfer-Encoding: chunked
Connection: keep-alive
Server: nginx
x-php-processing-time: 1.2999
x-result-code: 1
param: a2e42ad5eceb0ca669784ee9bc04060e739dbaa8
```

### Body
```
{
  "data_headers": {
    "force_update": false,
    "asset_update": true,
    "short_udid": null,
    "viewer_id": "<redacted>",
    "servertime": 1719092730,
    "result_code": 1
  },
  "data": []
}
```

