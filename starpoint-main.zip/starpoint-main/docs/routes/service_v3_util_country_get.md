# /service/v3/util/country/get
                       
## Request
### Headers
```
appId: 561429
appSecret: 8a4421148b884608bb96862f3988d832
Content-Type: application/json;charset=UTF-8
requestedBy: android
Connection: close
User-Agent: Dalvik/2.1.0 (Linux; U; Android 12; SM-T860 Build/SP2A.220305.013)
Host: gc-openapi-zinny3.kakaogames.com
Accept-Encoding: gzip
Content-Length: 0
```

### Body
```
No Request Body
```

## Response
### Headers
```
Content-Type: application/json;charset=UTF-8
Content-Length: 16
Connection: close
Date: Fri, 07 Jun 2024 18:47:28 GMT
Cache-Control: no-cache, no-store, max-age=0, must-revalidate
Pragma: no-cache
Expires: 0
startTime: 1717786048047
seq: 39659728
Access-Control-Allow-Origin: *
reqTime: 1717786048047
backendReqTime: 1717786048047
Access-Control-Allow-Credentials: true
Access-Control-Allow-Methods: GET, POST, DELETE, PUT, OPTIONS
resTime: 1717786048048
elapsed: 1
X-Cache: Miss from cloudfront
Via: 1.1 b30a70eb82ffb36639f346ad3bc8e3c6.cloudfront.net (CloudFront)
X-Amz-Cf-Pop: ATL59-P1
X-Amz-Cf-Id: GxE9GMIhu0T1OFQv_fRIcmITn0xL_9Gh6etNv5fUd07tuQ7EopOiuQ==
```

### Body
```
{
  "country": "us"
}
```

