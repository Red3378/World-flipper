# /latest/api/index.php/tool/signup
                       
## Request
### Headers
```
Host: na.wdfp.kakaogames.com
Accept-Encoding: deflate, gzip
Accept: text/xml, application/xml, application/xhtml+xml, text/html;q=0.9, text/plain;q=0.8, text/css, image/png, image/jpeg, image/gif;q=0.8, application/x-shockwave-flash, video/mp4;q=0.9, flv-application/octet-stream;q=0.8, video/x-flv;q=0.7, audio/mp4, application/futuresplash, */*;q=0.5
User-Agent: Mozilla/5.0 (Android; U; en-US) AppleWebKit/533.19.4 (KHTML, like Gecko) AdobeAIR/51.0
x-flash-version: 51,0,1,1
Connection: Keep-Alive
Referer: app:/worldflipper_android_release.swf
Content-Type: application/x-www-form-urlencoded
PARAM: ddb28f8c1dc57bd86131eb5f923b1257e9d92de0
GAME-APP-ID: ""
UDID: 8959A034-38B2-49A9-9F0C-6663706E07DD0521
COUNTRY_CODE: us
APP_ID: 561429
KAKAO_PID: 12
DEVICE_LANG: en
DEVICE_NAME: SM-T860 12
APP_VER: 0.0.81
DEVICE: 2
Content-Length: 444
```

### Body
```
{
  "access_token": "OhIh9EjEMXPxkfNGeUxTrJiSem3kD/YwOhDnV6ZshtgWe/kbh+gAJg/P24IBQEPJBlULRjAK",
  "storage_directory_path": "/data/user/0/com.kakaogames.wdfp/com.kakaogames.wdfp/Local Store/production---latest",
  "app_admin": "c14e19deb5c734b93a5e65c4d2099e0c",
  "kakao_pid": "12",
  "device_id": 2469028057024.0,
  "idp_code": "Guest",
  "app_secret": "8a4421148b884608bb96862f3988d832"
}
```

## Response
### Headers
```
Date: Fri, 07 Jun 2024 20:41:19 GMT
Content-Type: application/x-msgpack
Transfer-Encoding: chunked
Connection: keep-alive
Server: nginx
x-php-processing-time: 0.5030
x-result-code: 1
param: a385e172831773b70c0b9b921ee6d12a36dd2f63
```

### Body
```
{
  "data_headers": {
    "short_udid": 376249241,
    "viewer_id": "<redacted>",
    "udid": "8959A034-38B2-49A9-9F0C-6663706E07DD0521",
    "servertime": 1717792878,
    "result_code": 1
  },
  "data": []
}
```

